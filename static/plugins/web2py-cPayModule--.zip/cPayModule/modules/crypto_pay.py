#!/usr/bin/env python
# coding: utf8
#from gluon import *

# web2py gluon 
from gluon import URL, redirect
from gluon.tools import fetch
from gluon.contrib import simplejson as json

### This is module for a billing crypto-currency by cryptoPay.in service
### Это модуль для работы с криптовалютами через сервис cryptoPay.in

######################################################
### author Ermolaev Dmitry icreator@mail.ru (icreator)
######################################################
#
# constants - константы
#
test = True # show test messages

# Your shop_id in cryptoPay.in service or crypto-address
# ваш номер магазина на сервисе или адрес крипто кошелька
CP_SHOP_ID = '12'
# статус при котром засчитываем оплату - желательно выбрать HADR
CP_STATUS_OK = 'HARD' # SOFT, HARD, CLOSED

CP_URL_CHECK = 'http://cryptoPay.in/shop/api_bill/check.json/'
CP_URL_SHOW = 'http://cryptoPay.in/shop/bill/show/'
CP_URL_API = 'shop', 'api'
CP_URL_MAKE = 'shop', 'api_bill', 'make.json'
CP_URL_PARS = dict(host='cryptoPay.in', scheme='http')

# set a common parameters for all bills
# задаем общие параметры, передающиеся для всех создаваемых счетов
# see http://cryptopay.in/shop/default/api_docs
CP_URL_VARS = {
    # start notify my shop only from "HARD" status of the bill
    # посылать уведомления только при появлении статуса HARD и выше
    # = 'SOFT', 'HARD', 'CLOSED'
    'note_on': 'HARD', # защитывает оплату при появлении этого статуса
    # not convert incomed crypto-currencies to fiat money
    # не конвертировать поступившую криптовалюту
    'not_convert': 1,
    # currency for calculate cost - RUB EUR USD
    # валюта счета в которой задана цена счета
    'curr': 'RUB',
    # 'vol': 1000, # default volume if price = 0
    # 'public':1, # if you want make public bills
    # 'email': settings.email_adm,
    }
######################################################

'''
## define of table with orders
## Описание таблиц web2py: db.py

## Заказы - эта таблица уже в магазине есть. Пусть названия полей например будут такие:
db.define_table('orders_tab',
    Field('code', length=10, unique=True, comment=T('Произвольный номер заказа') ),
    Field('price', 'decimal(14,6)', default = 0.01, comment=T('Цена заказа')),
    Field('curr', length=3),
    Field('cp_pars', 'json', comment='дополнительные параметры для данного заказа'),
    Field('payed', 'boolean', comment='подтверждение оплаты'),
    )

## это вновь созданная - для хранения созданных счетов сервисом cryptoPay для ваших заказов
## при этом номер счета записывается прямо в "primary key" поле - id
db.define_table('cp_bills_tab',
    Field('order_ref', db.orders_tab ), ## ссылка на запись в таблице заказов
    Field('secret', length=8), ## секретный ключ для счета
    )
'''

# make url
# order_code - may be empty
# создает ссылку, номер заказа может быть пустой
def make_bill_url(db, order_rec, pars_in={}):

    # copy common parameters into url_vars
    # копируем - чтобы не поменять значения в константе
    url_vars = CP_URL_VARS.copy()

    ### update parameters
    
    if order_rec.code:
        url_vars[ 'order'] = order_rec.code
    else:
        ### if [order] is empty - it will be generate in cryptoPay bill
        ### если номер заказа пуст - он будет автоматически сгенерирован на сервисе
        pass

    if order_rec.price:
        url_vars[ 'price'] = order_rec.price
    else:
        ### if [price] is empty - it will be setted to 0 in cryptoPay bill
        ### если цена не задана то счет будет с нулевой ценой
        pass

    if order_rec.curr:
        url_vars[ 'curr'] = order_rec.curr
    else:
        ### if [curr] is empty - it will be setted to BTC in cryptoPay bill
        ### если валюта счета не задана то она установится в BTC на сервисе
        pass

    # if other pars is exist for this ORDER then update url_vars
    if order_rec.cp_pars:
        url_vars.update(order_rec.cp_pars)

    # other input pars update
    # добавим дополнительные параметры
    url_vars.update(pars_in)

    # generate URL for example - http://shop/api_bill/make.json/10?[url_vars]
    # создадим ссылку для команды make
    return URL(*CP_URL_MAKE, args=[CP_SHOP_ID], vars=url_vars, **CP_URL_PARS)

# создать код счета для запроса к сервису - либо с скретным ключом либо без него (только номер счета)
def get_cod(r):
    cod = '%s' % r.id
    if r.secret:
        cod += '.' + r.secret
    return cod

# проверка статусов в зависимости от заданного статуса приема платежа
# статус платежа проходит значения:
# SOFT -> HARD -> CLOSED = TRUE
# более подробно о статусах смотри в API
def is_status_ok(status):
    if CP_STATUS_OK == 'SOFT':
        return status in ['SOFT', 'HARD', 'CLOSED', 'TRUE']
    if CP_STATUS_OK == 'HARD':
        return status in ['HARD', 'CLOSED', 'TRUE']
    if CP_STATUS_OK == 'CLOSED':
        return status in ['CLOSED', 'TRUE']
#
# make new bill on cryptoPay.in
# создать новый счет - счет созддается в любом случае
# номер заказа тут не важен, для одного заказа можно создать несколько счетов
# поэтому здесь стоит проверка: сначала поиск уже созданного счета
def make_bill(db, order_rec, pars_in={}):
    
    # проверим - возможно уже счет для данного заказа создан
    bill_rec = db(db.cp_bills_tab.order_ref == order_rec.id).select().first()
    if bill_rec:
        # bill already maked
        # счет уже создан
        bill_cod = get_cod(bill_rec)
        #print 'already exist:', bill_cod
    else:
        # make URL for "make bill" command
        # создать ссылку
        url = make_bill_url(db, order_rec, pars_in)
        #print url

        # open url for make the bill
        # открыть ссылку
        ###  insread of:
        ###      import urllib
        ###      page = urllib.urlopen('http://www.web2py.com').read()
        ### - use fetch function - than correct open Google GAE`s pages
        resp = fetch(url)
        # print resp
        # >> resp = 2341.fg3Wdr1

        try:
            # split bill_id and secret_key
            # разделим результат по точке
            tab = resp.split('.')
            # is it integer?
            # это целое?
            bill_id = int(tab[0])
            bill_secret = len(tab)>1 and tab[1] or None
            bill_cod = resp
        except:
            # something wrong - error message
            # ошибка - сообщение об ошибке
            return resp
    
        #print 'update order_rec with', resp
        # save values from response: [bill_id] and [secret_key]
        # сохраним ответ как номер счета и секретный ключ
        # так как номер счета - это long integer, то запишем его прямо в id
        db.cp_bills_tab.insert( id = bill_id, order_ref = order_rec.id, secret = bill_secret )
        db.commit()

    ### redirect clients to http://cryptoPay.in/shop/bill/show/[cpay_bill_id]
    ### перенаправим клиента на показ созданного счета
    redirect(CP_URL_SHOW + bill_cod)

    
#
# check status of payments when receive a note your site from cryptoPay.in
# проверка статуса оплаты - когда ваш сайт принял уведомление от сервиса
# mess - for debug purposes
#
def on_note(db, pars):
    # take order bill_id from pars of note
    #
    bill_id = pars['bill']
    
    # find order record for that bill_id
    # поиск по номеру счета
    bill_rec = db.cp_bills_tab[ bill_id ]
    
    if not bill_rec:
        # if not found - ignore note
        #
        return 'ERROR: not mine'

    # make url for "check" command
    # создаем ссылку длля команды check
    url = CP_URL_CHECK + get_cod(bill_rec)
    
    # send "check" command and receive response
    #
    try:
        resp = fetch(url)
    
        # decode response as JSON
        #
        resp = json.loads( resp )
        #print resp
    except:
        return 'error to fetch /check.json', url
    
    if 'error' in resp:
        # some error...
        return resp
    
    # examinate this response
    #
    mess = ''
    #print resp
    order_rec = db.orders_tab[ bill_rec.order_ref ]
    if resp['price'] == order_rec.price and resp['curr'] == order_rec.curr:
        # parameters of the bill is true
        
        if not order_rec.code:
            # если у заказа не задан идентификатор (код)
            # то он будет сгенерирован на сервисе
            # возьмем его из уведомления
            order_rec.update_record( code = resp['order'])
            if test: mess += 'order code updated % <br>' % order_rec.code
            db.commit()
        # параметры ответа корректные
        if test: mess += ' parameters of the bill is true<br>'
        if is_status_ok(resp['status']):
            # status OK, update my order
            # статус подходящий, учтем оплату заказа
            order_rec.update_record( payed = True )
            db.commit()
            if test: mess += ' PAYED! status:%s<br>' % resp['status']
            return mess
    if test: mess += ' NOT PAYED, response: %s' % resp
    return mess
