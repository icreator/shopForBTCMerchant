<?php
class ControllerPaymentCryptoPay extends Controller {
	protected function index() {
        $this->language->load('payment/cryptopay');

        //текст кнопки подтверждения заказа
		$this->data['button_confirm'] = $this->language->get('button_confirm');
        //ссылка на страницу создания счета (далее - редирект на страницу оплаты на cryptoPay)
		$this->data['action'] = $this->url->link('payment/cryptopay/pay');

        //вывод шаблона
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/cryptopay.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/payment/cryptopay.tpl';
		} else {
			$this->template = 'default/template/payment/cryptopay.tpl';
		}
		$this->render();
	}
    public function pay()
    {
        //подключаем файл перевода
        $this->language->load('payment/cryptopay');
        //загружаем модель заказа
        $this->load->model('checkout/order');
        //сохраняем id заказа
        $order_id=$this->session->data['order_id'];

        //очищаем корзину
        if (isset($this->session->data['order_id'])) {
            $this->cart->clear();
            unset($this->session->data['shipping_method']);
            unset($this->session->data['shipping_methods']);
            unset($this->session->data['payment_method']);
            unset($this->session->data['payment_methods']);
            unset($this->session->data['guest']);
            unset($this->session->data['comment']);
            unset($this->session->data['order_id']);
            unset($this->session->data['coupon']);
            unset($this->session->data['reward']);
            unset($this->session->data['voucher']);
            unset($this->session->data['vouchers']);
        }
        //получаем инфо заказа
        $query=$this->db->query('select bill_id from '.DB_PREFIX.'cryptopay_bill where order_id='.$order_id);
        if($query->row)
        {
            $result=$query->row['bill_id'];
        }
        else
        {
            //создаем счет через АПИ
            $order_info = $this->model_checkout_order->getOrder($order_id);

			$m_id = $this->config->get('cryptopay_merchant'); //
			if (strlen($m_id)>30) {
				// если вместо ИД_магазина адрес кошелька - значит конвертацию не передаем
				$conv = '';
			} else {
				$conv = $this->config->get('cryptopay_payout');
				if ($conv == 'AS_IS') {
					$conv = '';
				} else {
					if ($conv == 'not_convert') {
						// запрет конвертации
						$conv = '&not_convert';
					} else {
						// иначе тут задана валюта длля конвертации
						$conv = '&conv_curr=' . $conv;
					}
				}
			}
			// время жизни счета проверим
			$expr = intval($this->config->get('cryptopay_expire'));
			if ($expr>10) {
				$expr = '&expire='.$expr;
			} else {
				$expr = '';
			}
            //создаем сслылку с параметрами
			$m_url = 'http://cryptopay.in/shop/api_bill/make/'.$this->config->get('cryptopay_merchant').'?order='.$order_id.
                $conv . $expr.
                ($this->config->get('cryptopay_public')=='public'?"&public":'').
                (trim($this->config->get('cryptopay_extended'))!=''?$this->config->get('cryptopay_extended'):'').
                '&curr='.$order_info['currency_code'].'&price='.$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false).
                (is_array($this->config->get('cryptopay_type'))?join('',array_map(function($type){return '&curr_in='.$type;}, $this->config->get('cryptopay_type'))):'');
			// работает !! trigger_error ( ' URL: ' . $m_url, E_USER_NOTICE );
			
			//trigger_error ( ' URL api make: ' . $m_url, E_USER_NOTICE );
			
			$curl=curl_init( $m_url );
            curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($curl,CURLOPT_TIMEOUT,5);
            curl_setopt($curl,CURLOPT_HEADER,0);
            $result=curl_exec($curl);
			
			//trigger_error ( ' result: ' . $result, E_USER_NOTICE );

            // ====================================
            // тут надо сделать проверку на возврат ошибки. ответы :
            // 2345  - пришел  только номер счета
            // 2345.fdg2fsrt3  - пришел секретный ключ с номером счета
            // ERROR: ....   - пришла ошибка
            // 
            // поэтому нужно вычленить число до точки и проверить - число ли это
            // если число то успех
            // иначе это сообщение об ошоибке - выход

            //сохраняем bill_id
            $this->db->query('insert ignore into '.DB_PREFIX.'cryptopay_bill set order_id='.$order_id.', bill_id="'.$result.'"');

            //"подтверждаем заказ"
			/// при этом созддаем в примечании ссылки на счет и ссылку длля принудительного запроса статуса оплаты
            $this->model_checkout_order->confirm($order_id,$this->config->get('config_order_status_id'),
				sprintf($this->language->get('text_payment_link'),
					// ссылка на счет
					'http://cryptopay.in/shop/bill/show/'.$result,
					// ссылка на прринудительный запрос информации о счете
					'index.php?route=payment/cryptopay/re_ask&bill='.$result.'&order='.$order_id),true);
        }
        //редирект на страницу оплаты
        $this->redirect('http://cryptopay.in/shop/bill/show/'.$result);
    }

    // функция на которую приходит уведомление от сервиса
	public function callback()
	{
        
        //загружаем файл перевода
        $this->language->load('payment/cryptopay');
        //получаем из запроса bill_id
		// @ - подавляет вызов ошибки
        @$bill_id=$this->request->get['bill'];
        @$order_id=$this->request->get['order'];
		
        // ================================================================
        // по заказу проверять нельзя - так как тут может быть создано несколько счетов на один заказ
        // надо сделать LIKE по счету и все
        //
        // проверяем наличие в базе
        $query=$this->db->query('select bill_id, order_id from '.DB_PREFIX.'cryptopay_bill where order_id="'.$order_id.'"');

        if($query->row)
        {
			// это наш счет прислал уведомление о смене статуса
			$bill_secret=$query->row['bill_id'];
            //проверяем оплату счета по api
			$curl=curl_init('http://cryptopay.in/shop/api_bill/check.json/'.$bill_secret);
			curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
			curl_setopt($curl,CURLOPT_TIMEOUT,5);
			curl_setopt($curl,CURLOPT_HEADER,0);
			$result = curl_exec($curl);
			//trigger_error ( ' result: ' . $result, E_USER_NOTICE );
			
			$result=json_decode($result);
			// ========================================
			// тут результатом может быть ошибка тоже - проверим
			if (isset($result->status))
			{
				$st = $result->status;
				$st_wait = $this->config->get('cryptopay_bill_status');
				
				//загружаем модель заказа
				$this->load->model('checkout/order');
					
				// проверим - может такой статус оплаты уже сообщался нам
				$query_hist=$this->db->query('select order_id from '.DB_PREFIX.'order_history where order_id="'.$order_id.
						'" and comment like "%' . $st . '%"');
				if($query_hist->row) {
					// такой статус уже есть в истории заказа - игнорируем
					// trigger_error ( ' status exist: ' . $st, E_USER_NOTICE );					
					return;
				}
				
				//если совпали статусы заказа - счет полностью оплачен
				if ($st=='CLOSED'
					|| $st=='HARD' && ($st_wait=='HADR' || $st_wait=='SOFT')
					|| $st=='SOFT' && $st_wait=='SOFT'
					) 
					{
					//ставим статус заказа "оплачен" (из настроек модуля оплаты)
					// и пошлем письма с уведомлениями
					$note_status = sprintf($this->language->get('text_payment_info_link'), $st);
					$this->model_checkout_order->update(
						$order_id,
						$this->config->get('cryptopay_order_status_id'),
						$note_status,
						true);
				} else {
					//ставим статус заказа "НЕ оплачен"
					$note_status = sprintf($this->language->get('text_payment_info_link_NOT'), $st);
					//trigger_error ( ' note_status: ' . $note_status, E_USER_NOTICE );
					$this->model_checkout_order->update(
						$order_id,
						7, // - Canceled $this->config->get('cryptopay_order_status_id'),
						$note_status,
						true); // true - вывод в списке статусов в истории заказов
				}
			}
        } else {
			// отладка что ничего не добавляем - запись не нашлась
			// $this->db->query("INSERT INTO log SET msg = 'row not found " . $bill_id ."'");
		}
	}

	// функция на которую приходит уведомление от сервиса
	public function re_ask()
	{
		$this->callback();
		//редирект на страницу оплаты
		$this->redirect('index.php?route=account/order/info&order_id='.$this->request->get['order']);
	}
}
?>