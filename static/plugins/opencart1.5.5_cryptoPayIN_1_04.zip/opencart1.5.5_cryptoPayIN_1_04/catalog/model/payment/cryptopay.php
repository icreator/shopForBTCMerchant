<?php 
class ModelPaymentCryptoPay extends Model {
	public function getMethod($address, $total) {
		$this->language->load('payment/cryptopay');

		if ($this->config->get('cryptopay_total') > 0 && $this->config->get('liqpay_total') > $total) {
			$status = false;
		} else {
			$status = true;
		}

		$method_data = array();

		if ($status) {
			$method_data = array(
				'code'       => 'cryptopay',
				'title'      => $this->language->get('text_title'),
				'sort_order' => $this->config->get('cryptopay_sort_order')
			);
		}

		return $method_data;
	}
}
?>