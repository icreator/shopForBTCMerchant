<?php
// Text
$_['text_title'] = '<img src="http://cryptopay.in/shop/static/images/logo1.png" width="120" class="center"> - криптовалютами: bitcoin, litecoin, NVC, CLR...';
$_['text_payment_link'] = 'Создан <b><a href="%s"  target="_blank" class="button">cчет</a></b> на оплату. '.
	'Вы можете <b><a href="%s" class="button">проверить оплату</a></b> вручную';
$_['text_payment_info_link'] = 'Счет оплачен. Статус: [%s]';
$_['text_payment_info_link_NOT'] = 'Счет НЕ оплачен. Статус: [%s]';
?>