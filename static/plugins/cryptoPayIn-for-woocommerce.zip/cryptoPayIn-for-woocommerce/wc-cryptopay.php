<?php
/*
  Plugin Name: Cryptopay.in Payment Gateway
  Plugin URI: 
  Description: Allows you to use cryptopay.in payment gateway with the WooCommerce plugin.
  Version: 0.9
  Author: i-creator
  Author URI: http://cryptopay.in
 */




if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function cryptopay_rub_currency_symbol( $currency_symbol, $currency ) {
    if($currency == "RUB") {
        $currency_symbol = 'р.';
    }
    return $currency_symbol;
}

function cryptopay_rub_currency( $currencies ) {
    $currencies["RUB"] = 'Russian Roubles';
    return $currencies;
}

function create_bill_table()
{
    global $wpdb;
    $wpdb->query('CREATE TABLE IF NOT EXISTS `'.$wpdb->prefix.'cryptopay_bill` (
                  `order_id` int(11) NOT NULL,
                  `bill_id` varchar(255) NOT NULL,
                  PRIMARY KEY (`order_id`),
                  KEY `order_id` (`order_id`,`bill_id`)
                )  DEFAULT CHARSET=utf8;');
}
register_activation_hook( __FILE__, 'create_bill_table' );
add_filter( 'woocommerce_currency_symbol', 'cryptopay_rub_currency_symbol', 10, 2 );
add_filter( 'woocommerce_currencies', 'cryptopay_rub_currency', 10, 1 );

/* добавляем класс оплаты в woocommerce
  ------------------------------------------------------------ */
add_action('plugins_loaded', 'woocommerce_cryptopay', 0);
function woocommerce_cryptopay(){
	if (!class_exists('WC_Payment_Gateway'))
		return;
	if(class_exists('WC_CRYPTOPAY'))
		return;
class WC_CRYPTOPAY extends WC_Payment_Gateway{
	public function __construct(){

		$plugin_dir = plugin_dir_url(__FILE__);

		global $woocommerce;
		$this->id = 'cryptopay';
		$this->icon = apply_filters('woocommerce_cryptopay_icon', ''.$plugin_dir.'cryptopay.png');
        $this->enabledCurrencies=array('RUB', 'USD', 'EUR', 'BTC', 'LTC', 'NVC', 'CLR');
        $this->enabledCryptoCurrencies=array('BTC'=>'BTC', 'LTC'=>'LTC', 'NVC'=>'NVC', 'CLR'=>'CLR');
		$this->has_fields = false;
        $this->api_url = 'http://cryptopay.in/shop/api_bill/';
        $this->show_url = 'http://cryptopay.in/shop/bill/show/';


		// Загрузка настроек
		$this->init_form_fields();
		$this->init_settings();
        $this->title = $this->get_option('title');

		// Actions
		add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

		// Сохранение настроек
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		// обработчик уведомлений от cryptopay
		add_action('woocommerce_api_wc_' . $this->id, array($this, 'cryptopay_callback'));

		if (!$this->is_valid_for_use()){
			$this->enabled = false;
		}
	}

	/**
	 * Проверка текущей валюты магазина
	 */
	function is_valid_for_use(){
		if (!in_array(get_option('woocommerce_currency'), $this->enabledCurrencies)){
			return false;
		}
		return true;
	}

	/**
     * Страница настроек модуля в админке
	**/
	public function admin_options() {
		?>
		<h3><?php _e('CRYPTOPAY', 'woocommerce'); ?></h3>
		<p><?php _e('В настройках магазина на cryptopay.in укажите:', 'woocommerce'); ?></p>
		<p>note_url= <input type="text" value="index.php?wc-api=wc_cryptopay&" readonly style="width: 400px"/></p>
		<p>back_url= <input type="text" value="index.php?wc-api=wc_cryptopay&back&" readonly style="width: 400px"/></p>

	  <?php if ( $this->is_valid_for_use() ) : ?>

		<table class="form-table">

		<?php
    			// Generate the HTML For the settings form.
    			$this->generate_settings_html();
    ?>
    </table><!--/.form-table-->

    <?php else : ?>
		<div class="inline error"><p><strong><?php _e('Шлюз отключен', 'woocommerce'); ?></strong>: <?php _e('CRYPTOPAY не поддерживает валюты Вашего магазина.', 'woocommerce' ); ?></p></div>
		<?php
			endif;

    }

  /**
  * Поля для формы настройки модуля
  */
	function init_form_fields(){
        $this->form_fields = array(
				'enabled' => array(
					'title' => __('Включить/Выключить', 'woocommerce'),
					'type' => 'checkbox',
					'label' => __('Включен', 'woocommerce'),
					'default' => 'yes'
				),
				'title' => array(
					'title' => __('Название', 'woocommerce'),
					'type' => 'text',
					'description' => __( 'Это название, которое пользователь видит во время оформления заказа.', 'woocommerce' ),
					'default' => __('CRYPTOPAY', 'woocommerce')
				),
				'cryptopay_merchant' => array(
					'title' => __('ID магазина', 'woocommerce'),
					'type' => 'text',
					'description' => __('', 'woocommerce'),
					'default' => ''
				),
				'cryptopay_curr_in' => array(
					'title' => __('Валюта для создания счетов оплаты', 'woocommerce'),
					'type' => 'hidden',
					'description' => __('Оплата через CryptoPay доступна только с валютами '.join(', ',array_keys($this->enabledCurrencies)).' (текущая валюта магазина - '.get_option('woocommerce_currency').')', 'woocommerce'),
					'default' => ''
				),
                'cryptopay_type' => array(
                    'title'       => __( 'Список криптовалют, которые разрешены для оплаты счетов', 'woocommerce' ),
                    'type'        => 'multiselect',
                    'css'       => 'width:25em;',
                    'description' => __( '<b>Выборать несколько валют можно зажав клавишу Ctrl.</b><br>Если ничего не выбрано, то принимаются все криптовалюты, которые обрабатывает сервис. Например, Вы можете выбрать только BTC и LTC и задать параметр "Валюта для выплат"="Без конвертации" - тогда пользователь при оплате Вашего счета сможет оплачитвать только биткоинами и лайткоинами, которые без конвертации будут поступать Вам на балланс.', 'woocommerce' ),
                    'options'     => $this->enabledCryptoCurrencies,
                ),

                'cryptopay_payout' => array(
                    'title'       => __( 'Валюта в которую будут конвертироваться входящие платежи', 'woocommerce' ),
                    'type'        => 'select',
                    'description' => __( 'В ней Вы будете получать выплаты с сервиса.<br>Если выбрано "без конвертации" то входящая криптовалюта будет начисляться магазину в том виде в котром пришла.', 'woocommerce' ),
                    'default'     => 'no_convert',
                    'css'       => 'width:25em;',
                    'options'     => array(
                        'BTC' => __( 'BTC', 'woocommerce' ),
                        'LTC' => __( 'LTC', 'woocommerce' ),
                        'NVC' => __( 'NVC', 'woocommerce' ),
                        'CLR' => __( 'CLR', 'woocommerce' ),
                        'RUB' => __( 'RUB', 'woocommerce' ),
                        'USD' => __( 'USD', 'woocommerce' ),
                        'EUR' => __( 'EUR', 'woocommerce' ),
                        'no_convert' => __( 'Без конвертации', 'woocommerce' ),
                    )
                ),

                'cryptopay_public' => array(
                    'title'       => __( 'Открытость счетов', 'woocommerce' ),
                    'type'        => 'select',
                    'description' => __( 'По умолчанию - "Закрыто всем", то есть доступ к инфоормации по счетам возможен только с секретнным ключом, который передается Вашему магазину для каждого созданного счета.', 'woocommerce' ),
                    'default'     => 'None',
                    'css'       => 'width:25em;',
                    'options'     => array(
                        'public' => __( 'Открыто всем', 'woocommerce' ),
                        'None' => __( 'Закрыто всем', 'woocommerce' ),
                    )
                ),

                'cryptopay_order_status' => array(
                    'title'       => __( 'Статус заказа после подтверждения оплаты', 'woocommerce' ),
                    'type'        => 'select',
                    'description' => __( 'Этот статус автоматически устанавливается после оплаты заказа покупателем и подтверждения со стороны CryptoPay', 'woocommerce' ),
                    'default'     => 'processing',
                    'css'       => 'width:25em;',
                    'options'     => array(
                        'pending' => __( 'pending', 'woocommerce' ),
                        'failed' => __( 'failed', 'woocommerce' ),
                        'on-hold' => __( 'on-hold', 'woocommerce' ),
                        'processing' => __( 'processing', 'woocommerce' ),
                        'completed' => __( 'completed', 'woocommerce' ),
                        'refunded' => __( 'refunded', 'woocommerce' ),
                        'cancelled' => __( 'cancelled', 'woocommerce' ),
                    )
                ),
                'cryptopay_bill_status' => array(
                    'title'       => __( 'Статус счета, не ранее которого присылать уведомления с сервиса', 'woocommerce' ),
                    'type'        => 'select',
                    'css'       => 'width:25em;',
                    'default'     => 'HARD',
                    'options'     => array(
                        'HARD' => __( 'HARD', 'woocommerce' ),
                        'CLOSED' => __( 'CLOSED', 'woocommerce' ),
                    )
                ),


                'cryptopay_expire' => array(
                    'title'       => __( 'Продолжительность жизни счета в минутах ', 'woocommerce' ),
                    'type'        => 'text',
                    'description' => __( '', 'woocommerce' ),
                    'default'     => 180,
                ),


				'cryptopay_extended' => array(
					'title' => __( 'Список дополнительных параметров', 'woocommerce' ),
					'type' => 'textarea',
					'description' => __( 'Более подробно о параметрах в <a href="https://docs.google.com/document/d/1hrAocgSS0ZuBvgLr6oS_dKDFhdQwL12qTJCBTaykzSg/edit#heading=h.iii87ixk2pjt" target="_blank">описании API</a>', 'woocommerce' ),
					'default' => ''
				),

                'description' => array(
					'title' => __( 'Description', 'woocommerce' ),
					'type' => 'textarea',
					'description' => __( 'Описанием метода оплаты которое клиент будет видеть на вашем сайте.', 'woocommerce' ),
					'default' => 'Оплата с помощью cryptopay.'
				),
				'instructions' => array(
					'title' => __( 'Instructions', 'woocommerce' ),
					'type' => 'textarea',
					'description' => __( 'Инструкции, которые будут добавлены на страницу благодарностей.', 'woocommerce' ),
					'default' => 'Оплата с помощью cryptopay.'
				)
			);
	}

	/**
	* Создаем счет и кнопку перехода к оплате
	**/
	public function generate_form($order_id){
		global $woocommerce, $wpdb;

		$order = new WC_Order( $order_id );

        if(!$result=$wpdb->get_var( 'select bill_id from '.$wpdb->prefix.'cryptopay_bill where order_id='.$order_id ))
        {
            //создаем счет через АПИ
            $curl=curl_init($this->api_url.'make/'.$this->get_option('cryptopay_merchant').'?order='.$order_id.
                ($this->get_option('cryptopay_payout')!='no_convert'?"&conv_curr=".$this->get_option('cryptopay_payout'):'&no_convert').
                ($this->get_option('cryptopay_public')!='None'?"&public":'').
                ($this->get_option('cryptopay_expire')!=''?"&expire=".$this->get_option('cryptopay_expire'):'').
                (trim($this->get_option('cryptopay_extended'))!=''?$this->get_option('cryptopay_extended'):'').

                '&curr='.get_option('woocommerce_currency').'&price='.number_format($order->order_total, 2, '.', '').
                (count($this->get_option('cryptopay_type'))?join('',array_map(function($type){return '&curr_in='.$type;},$this->get_option('cryptopay_type'))):''));
            curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($curl,CURLOPT_TIMEOUT,10);
            curl_setopt($curl,CURLOPT_HEADER,0);
            $result=curl_exec($curl);
            list($bill_id,$secret)=explode('.',$result);
            if(!preg_match_all('#^\d+$#',$bill_id))
            {
                return __('<b>Ошибка создания счета на оплату</b>','woocommerce');
            }
            //сохраняем bill_id
            $wpdb->query('insert ignore into '.$wpdb->prefix.'cryptopay_bill set order_id='.$order_id.', bill_id="'.$result.'"');
            $order->update_status('pending', '<a href="'.$this->show_url.$result.'" target="_blank">'.__('Счет создан', 'woocommerce').'</a> - '.__('Счет создан', 'woocommerce'));
        }
        $order->update_status('pending', '<a href="'.$this->show_url.$result.'" target="_blank">'.__('Счет создан', 'woocommerce').'</a> - '.__('Счет создан', 'woocommerce'));
        return
            '<form action="'.esc_url($this->show_url.$result).'" method="POST">'."\n".
            '<input type="submit" class="button alt" id="submit_cryptopay_payment_form" value="'.__('Оплатить', 'woocommerce').'" /> <a class="button cancel" href="'.$order->get_cancel_order_url().'">'.__('Отказаться от оплаты & вернуться в корзину', 'woocommerce').'</a>'."\n".
            '</form>';
	}

    function process_payment($order_id){
        $order = new WC_Order($order_id);

        return array(
            'result' => 'success',
            'redirect'	=> add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
        );
    }

	/**
	* Тест на странице с кнопкой оплаты
	**/
	function receipt_page($order){
		echo '<p>'.__('Спасибо за Ваш заказ, пожалуйста, нажмите кнопку ниже, чтобы заплатить.', 'woocommerce').'</p>';
		echo $this->generate_form($order);
	}

    /**
     * обработка уведомлений от cryptopay.in
     **/
	function cryptopay_callback(){

		global $woocommerce, $wpdb;

        //обработка ссылки возврата в магазина
        if (isset($_GET['back']))
        {
            $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
            if ( $myaccount_page_id ) {
                $myaccount_page_url = get_permalink( $myaccount_page_id );
            }
            wp_redirect($myaccount_page_url);
            exit;
        }

        @$order_id=isset($_GET['order_id'])?$_GET['order_id']:$_GET['order'];
        @$bill_id=isset($_GET['bill_id'])?$_GET['bill_id']:$_GET['bill'];
        if($order_id && $bill_id)
        {

            // проверяем наличие в базе
            if($bill_secret=$wpdb->get_var('select bill_id from '.$wpdb->prefix.'cryptopay_bill where order_id='.$order_id.' and bill_id like "'.$bill_id.'%"'))
            {
                //проверяем оплату счета по api
                $curl=curl_init($this->api_url.'check.json/'.$bill_secret);
                curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($curl,CURLOPT_TIMEOUT,5);
                curl_setopt($curl,CURLOPT_HEADER,0);
                $result=json_decode(curl_exec($curl));
                //если совпали order_id, статусы заказа и счет полностью оплачен
                if($result->order==$order_id &&
                    ($result->status==$this->get_option('cryptopay_bill_status') || $result->status=='CLOSED' || $result->status=='TRUE')
                    && $result->price==$result->payed)
                {
                    //обновляем ордер
                    $order = new WC_Order($order_id);
                    $order->update_status($this->get_option('cryptopay_order_status'), '');
                }

            }
        }
	}
}

/**
 * добавляем метод оплаты в woocommerce
 **/
function add_cryptopay_gateway($methods){
	$methods[] = 'WC_CRYPTOPAY';
	return $methods;
}
add_filter('woocommerce_payment_gateways', 'add_cryptopay_gateway');
}
?>