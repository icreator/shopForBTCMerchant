Documentation

How to Install
Unpack .zip in any folder
Copy files from /LITEcash to  [PrestaShop]/modules
There must be structure: [PrestaShop]/modules/LITEcash/LITEcash.php

In admin panel switch on modile LITEcash
Make Quick registration
Save settings
Try make order

