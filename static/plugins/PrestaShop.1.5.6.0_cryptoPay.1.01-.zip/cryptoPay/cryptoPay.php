<?php
/*
* 2007-2013 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2013 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
	exit;

class CryptoPay extends PaymentModule
{
	private $_html = '';
	private $_postErrors = array();

	public $cryptopay_id;
	public $note_url;
	public $back_url;
	public $extra_mail_vars;
	public function __construct()
	{
		$this->name = 'cryptopay';
		$this->tab = 'payments_gateways';
		$this->version = '1.0.1';
		$this->author = 'PrestaShop';
		
		$this->currencies = true;
		$this->currencies_mode = 'checkbox';
		

		$config = Configuration::getMultiple(array('CRYPTO_PAY_ID', 'CRYPTO_PAY_STATUS', 'CRYPTO_PAY_BTC', 'CRYPTO_PAY_LTC'));
		$this->dat = $config;
		if (isset($config['CRYPTO_PAY_STATUS']))
			$this->status = $config['CRYPTO_PAY_STATUS'];
		if (isset($config['CRYPTO_PAY_ID']))
			$this->cryptopay_id = $config['CRYPTO_PAY_ID'];
//		if (isset($config['CRYPTO_PAY_BTC']))
//			$this->btc = $config['CRYPTO_PAY_BTC'];
//		if (isset($config['CRYPTO_PAY_LTC']))
//			$this->ltc = $config['CRYPTO_PAY_LTC'];			
//		if (isset($config['CRYPTO_PAY_BACK_URL']))
//			$this->back_url = $config['CRYPTO_PAY_BACK_URL'];
		Configuration::updateValue('CRYPTO_PAY_BTC', "BTC");
		






		parent::__construct();

		$this->displayName = $this->l('CryrtoPay');
		$this->description = $this->l('Accept payments for your products via cryptopay.');
		$this->confirmUninstall = $this->l('Are you sure about removing these details?');
		if (!isset($this->cryptopay_id) || !isset($this->back_url))
			$this->warning = $this->l('Account owner and account details must be configured before using this module.');
		if (!count(Currency::checkPaymentCurrencies($this->id)))
			$this->warning = $this->l('No currency has been set for this module.');

		$this->extra_mail_vars = array(
										'{cryptopay_url}' => nl2br(Configuration::get('CRYPTO_PAY_ID')),
										'{cryptopay_back_url}' => nl2br(Configuration::get('CRYPTO_PAY_STATUS'))
										);
	}

	public function install()
	{
		if (!parent::install() || !$this->registerHook('payment') || !$this->registerHook('paymentReturn'))
			return false;
		return true;
	}

	public function uninstall()
	{
		if (!Configuration::deleteByName('CRYPTO_PAY_ID')
				|| !Configuration::deleteByName('CRYPTO_PAY_STATUS')
				|| !Configuration::deleteByName('CRYPTO_PAY_BTC')
				|| !Configuration::deleteByName('CRYPTO_PAY_LTC')			
				|| !parent::uninstall())
			return false;
		return true;
	}

	private function _postValidation()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			if (!Tools::getValue('cryptopay_id'))
				$this->_postErrors[] = $this->l('Account details are required.');

		}
	}

	private function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			Configuration::updateValue('CRYPTO_PAY_ID', Tools::getValue('cryptopay_id'));
			Configuration::updateValue('CRYPTO_PAY_STATUS', Tools::getValue('status'));
//			Configuration::updateValue('CRYPTO_PAY_BTC', Tools::getValue('btc'));
//			Configuration::updateValue('CRYPTO_PAY_LTC', Tools::getValue('ltc'));
		}
		$this->_html .= '<div class="conf confirm"> '.$this->l('Settings updated').'</div>';
		
	}

	private function _displayCryptoPay()
	{
		$this->_html .= '<a  href="http://www.cryptopay.in"><img src="../modules/cryptopay/cryptopay.png" style="float:left; margin-right:15px;" width="200" height="60"></a><b>'.$this->l('This module allows you to make secure payments BITCOIN, LITECOIN via Cryptopay.in.').'</b><br /><br />
		'.$this->l('If the client chooses to pay by Cryptopay.in, the order\'s status will change to "Waiting for Payment."').'<br />
		'.$this->l('After payment through Cryptopay.in order status is automatically changed to "Paid".').'<br />'
		. $this->l('Please install Curl library in file php.ini (extension=php_curl.dll)').'<br />
		<a href="https://docs.google.com/document/d/1hrAocgSS0ZuBvgLr6oS_dKDFhdQwL12qTJCBTaykzSg/edit?usp=sharing"><b><ins>'. $this->l('Help Me!') .'</ins></b></a><br /><br />';
	}

	private function _displayForm()
	{
		
		$this->_html .=
		'<form action="'.Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']).'" method="post">
			<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Contact details').'</legend>
				<table border="0" width="900" cellpadding="0" cellspacing="0" id="form" >
					<tr><td colspan="2">'.$this->l('Please specify the cryptopay account details.').'.<br /><br /></td></tr>
						<tr>
						<td style="vertical-align: top;  width: 120px;">'.$this->l('cryptopay_id').'</td>
						<td style="padding-bottom:15px; width: 160px;">
							<input name="cryptopay_id" type="text" value="'.htmlentities(Tools::getValue('cryptopay_id', $this->cryptopay_id), ENT_COMPAT, 'UTF-8').'">
							
						</td>
						<td style="padding-bottom:15px;">
						<a  href="http://www.cryptopay.in/shop/add/index"><ins>'.$this->l('To obtain the code, log CruptoPay.in').'</ins></a>
						</td>
					</tr>
					<tr>
						<td width="130" style="vertical-align: top;">'.$this->l('Status').'</td>
						<td style="padding-bottom:15px;">
						<!--	<textarea  rows="4" cols="53">'.htmlentities(Tools::getValue('status', $this->status), ENT_COMPAT, 'UTF-8').'</textarea>  -->
							 <select name="status">
							<option  ' .$this->closed.'>CLOSED</option>
							<option    '.$this->hard.'>HARD</option>
							<option  ' .$this->soft.'>SOFT</option>
							</select> 
						</td>
						<td>
						'.$this->l('Select the user from making payments').'<br>
SOFT - '. $this->l('without confirmation. Payment is received instantly, payment security is not high') .', <br>
HARD - '. $this->l('confirmation. Average arrival time, high security') .', <br>
CLOSED - '. $this->l('fully confirmed. Maximum time of receipt of payment') .'. <br>
						</td>
					</tr> 
				<!--	<tr><td>
					CURRENCIES: </td><td>
					<p><input type="checkbox" name="btc" value="BTC"  checked>BTC</p>
					<p><input type="checkbox" name="ltc" value="LTC" >LTC</p>
					</td><td>
					выберите валюту которой могут платить ваши клиенты  checked
					</td></tr> -->
					<tr><td colspan="2" align="center"><input class="button" name="btnSubmit" value="'.$this->l('Update settings').'" type="submit" /></td></tr>
				</table>
			</fieldset>
		</form>';
	}

	public function getContent()
	{
		$this->_html = '<h2>'.$this->displayName.'</h2>';
		
		
		if (Tools::isSubmit('btnSubmit'))
		{
			$this->_postValidation();
		
		
		if (!count($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors as $err)
					$this->_html .= '<div class="alert error">'.$err.'</div>';
		}
		else
			$this->_html .= '<br />';

	$dat = Configuration::getMultiple(array('CRYPTO_PAY_ID', 'CRYPTO_PAY_STATUS', 'CRYPTO_PAY_BTC', 'CRYPTO_PAY_LTC'));
        $this->soft= '';
		$this->hard= '';
		$this->closed= '';
		if ($dat['CRYPTO_PAY_STATUS'] =="SOFT") $this->soft= 'SELECTED';
		if ($dat['CRYPTO_PAY_STATUS'] =="HARD") $this->hard= 'SELECTED';
		if ($dat['CRYPTO_PAY_STATUS'] =="CLOSED") $this->closed= 'SELECTED';

//		$this->btc1= '';
//		$this->ltc1= '';
//		if($dat['CRYPTO_PAY_BTC'] =="BTC") $this->btc1="checked";
//		if($dat['CRYPTO_PAY_LTC'] =="LTC") $this->ltc1="checked";
	
	
		$this->_displayCryptoPay();
		$this->_displayForm();

		return $this->_html;
	}

	public function hookPayment($params)
	{
		if (!$this->active)
			return;
		if (!$this->checkCurrency($params['cart']))
			return;


		$this->smarty->assign(array(
			'this_path' => $this->_path,
			'this_path_bw' => $this->_path,
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
		));
		return $this->display(__FILE__, 'payment.tpl');
	}

	public function hookPaymentReturn($params)
	{
		if (!$this->active)
			return;

		$state = $params['objOrder']->getCurrentState();
		if ($state == Configuration::get('PS_OS_CHEQUE') || $state == Configuration::get('PS_OS_OUTOFSTOCK'))
		{
			$this->smarty->assign(array(
				'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
				'cryptopayurl' => Tools::nl2br($this->cryptopay_id),
				'cryptopayback_url' => Tools::nl2br($this->back_url),
				'cryptopaystatus' => $this->status,
				'status' => 'ok',
				'id_order' => $params['objOrder']->id
			));
			if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference))
				$this->smarty->assign('reference', $params['objOrder']->reference);
		}
		else
			$this->smarty->assign('status', 'failed');
		return $this->display(__FILE__, 'payment_return.tpl');
	}
	
	public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

		if (is_array($currencies_module))
			foreach ($currencies_module as $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
		return false;
	}
}
