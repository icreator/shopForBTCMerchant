<?php
/*
* 2007-2013 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2013 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class CryptopayValidationModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{
		$cart = $this->context->cart;
		if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
			Tools::redirect('index.php?controller=order&step=1');

		// Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
		$authorized = false;
		foreach (Module::getPaymentModules() as $module)
			if ($module['name'] == 'cryptopay')
			{
				$authorized = true;
				break;
			}
		if (!$authorized)
			die($this->module->l('This payment method is not available.', 'validation'));

		$customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer))
			Tools::redirect('index.php?controller=order&step=1');

		$currency = $this->context->currency;
		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
//		$mailVars = array(
//			'{url}' => Configuration::get('CRYPTO_PAY_URL'),
//			'{note_url}' => nl2br(Configuration::get('CRYPTO_PAY_NOTE_URL')),
//			'{back_url}' => nl2br(Configuration::get('CRYPTO_PAY_BACK_URL'))
//		);
		$id_lang = $this->context->cart->id_lang;
		$lang = new Language($id_lang);


	$this->module->validateOrder($cart->id, Configuration::get('PS_OS_CHEQUE'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
	$redir='http://cryptoPay.in/shop/bill/show/'.Configuration::get('CRYPTO_PAY_ID'). '?order='.  $this->module->currentOrderReference  .'&price=' . $total . '&curr='. $currency->iso_code .'&note_on='.Configuration::get('CRYPTO_PAY_STATUS').'&back_url=history.php&lang=' .$lang->iso_code;
    Tools::redirect($redir);
	
function error_1($str)
{
	global $log_fp;
	mysql_query("ROLLBACK;");
 	echo "$str<br>";
	fwrite($log_fp, date('Y-m-d H:i:s') . " ---------------- END Error!!! ---- " . $str . " ---------------------------\n"); // Запись в файл
	fclose($log_fp); //Закрытие файла
	exit;
}	









		
	}
}
