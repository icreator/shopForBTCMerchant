<?php
/*
* 2007-2013 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2013 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class cryptopayControlsModuleFrontController extends ModuleFrontController
{
// включаем SSL шифрование
	public $ssl = true;
	
	
	public function postProcess()
	{
	


// модуль для запроса о оплате счета через cryptopay при инициализации от cryptopay
// ссылка на работу модуля  при зачислении оплаты клиента
// ../index.php?fc=module&module=cryptopay&controller=controls&order=%(order_id)s
// параметры....
// 'order'               номер референса 

// открываем файл истории для записи и переводим указатель в конец файла
	$log_name  = dirname(__FILE__) .'\cryptopay.log';
	
//	echo $log_name;
	if (!file_exists($log_name)) 
	{
		echo 'LOG???';
		exit;
	}
	$log_fp = fopen($log_name, 'at'); 

// проверка если не локальный наш сервер отправил, то ошибка...
//print_r($_SERVER);
//echo $_SERVER['REMOTE_ADDR'];
//if ($_SERVER['REMOTE_ADDR'] != '137.117.132.51' )	error_1("<br>IP - ok????", $log_fp);	


	fwrite($log_fp, "opder:".Tools::getValue('order'). " \n"); // Запись в файл
// делаем запрос о статусе заказа с cryptopay
$domain = "http://cryptoPay.in/shop/bill/check/". Configuration::get('CRYPTO_PAY_ID'); //  ?order=w23a1
//echo $domain ."<br>";
//Проверка на правильность URL 
	if(!filter_var($domain, FILTER_VALIDATE_URL)) error_1("domain???", $log_fp);
// делаем цикл для отправки данных по адресам
	$response ="";
	$postData = array(
	'order' => Tools::getValue('order')
	);
		

//Инициализация curl
		$curlInit = curl_init($domain);
		curl_setopt($curlInit, CURLOPT_POST, 1);
// устанавлваем даные для отправки
		curl_setopt($curlInit, CURLOPT_POSTFIELDS, $postData);
// флаг о том, что нужно получить результат
		curl_setopt($curlInit, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,10);
		curl_setopt($curlInit,CURLOPT_HEADER,false);
		curl_setopt($curlInit,CURLOPT_NOBODY,false);
		curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);
//Получаем ответ
		$response = curl_exec($curlInit);
// закрываем curl
		curl_close($curlInit);
// обработка результата
//		if ($response == "998") error_1("998");
//		if ($response == "997") error_1("997");
//		if ($response == "500") error_1("500");

// если все хорошо!!!
/*		if ($response == "999") 
		{
			mysql_query("COMMIT");
			
			echo "999 ok!";
			fwrite($log_fp, "Code:".$response . " \n"); // Запись в файл
			fwrite($log_fp, date('Y-m-d H:i:s') . " params: \n"); // Запись в файл
			fwrite($log_fp, $post_param ); // Запись в файл
			fwrite($log_fp, date('Y-m-d H:i:s') . " ---------------- END OK!!!------------------------------------------------------ \n"); // Запись в файл
			fclose($log_fp); //Закрытие файла
			break;
		}
		echo "!!!! cod = " . $response  . " !!!!!!!!<bt>";
		fwrite($log_fp, date('Y-m-d H:i:s') . " Error!!! cod=" . $response . " !!!!!!!!!!!!!!!!!!!!!!!!\n"); // Запись в файл
//	}
*/
//echo "<br>";
fwrite($log_fp, "json:".$response. " \n"); // Запись в файл			
				
// проверка на начальеные данные
// определяем id_order  по номеру reference 
	$sql_1	= 'SELECT * FROM `'._DB_PREFIX_.'orders` WHERE `reference` = "'. Tools::getValue('order'). '";' ;
	$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS($sql_1);
	if (!$result) error_1(' not order  ' . Tools::getValue('ref'), $log_fp);
//определяем номер ордера	
	$id_order = $result[0]['id_order'];
// создаем объект ордера
	$order = new Order($id_order);	


// находим id_order_invoce
     $sql_1	= 'SELECT * FROM `'._DB_PREFIX_.'order_invoice` WHERE `id_order` = '. $id_order. ';' ;
	
	if(	!$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS($sql_1))
	{
// если не сгенерирован инвойс мы его генерим
	if (!Configuration::get('PS_INVOICE', null, null, $order->id_shop))
				error_1('Invoice management has been disabled.',  $log_fp);
			elseif ($order->hasInvoice())
				error_1('This order already has an invoice.' , $log_fp);
			else
			{
				$order->setInvoice(true);
// опять вычисляем номер инвойса
			$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS($sql_1);
			}
	
	
	}
	$id_order_invoice = $result[0]['id_order_invoice'];

// декодируем полученные данные
$obj_date = json_decode($response);	

// проверяем если счет оплачен то выходим
if ($order->valid == 1) error_1('Ордер уже оплачен' ,$log_fp ) ;
// смотрим сумму платежа
$total = $order->total_paid;
//$tt=$total *1.00;
$curr = new Currency ($order->id_currency);
//echo $curr->iso_code .'<br>';
//echo $obj_date->curr;
if ($total*1.00 != $obj_date->payed *1.00) error_1('Сумма не совпадает Ордер = '.$total.', Оплата='. $obj_date->payed , $log_fp );
if ($obj_date->curr != $curr->iso_code) error_1('Валюты не совпадают запрос = '.$curr->iso_code.', ответ ='. $obj_date->curr , $log_fp );
if ($obj_date->status =="SOFT" || $obj_date->status =="HARD" || $obj_date->status=="CLOSED") $a=1;
	else {
	error_1('Статус??? = '.$obj_date->status , $log_fp );
	}



// транзакция
$payment_transaction_id = "CryptoPay.in";
// дата
	$date = date('Y-m-d H:i:s');
//сумма
	$amount = $total;
// метод
$payment_method = 'CryptoPay.in';
// вычисляем валюту
$id_curr = $order->id_currency;
	$currency = new Currency($id_curr);
	$order_has_invoice = $order->hasInvoice();
	if ($order_has_invoice)
	$order_invoice = new OrderInvoice($id_order_invoice);
		else
		$order_invoice = null;
//	print_r($order_invoice);
	if (!Validate::isLoadedObject($order))
		error_1 ('The order cannot be found', $log_fp);
	elseif (!Validate::isNegativePrice($amount) || !(float)$amount)
		error_1 ('The amount is invalid.', $log_fp);
	elseif (!Validate::isString($payment_method))
		error_1 ('The selected payment method is invalid.' , $log_fp);
	elseif (!Validate::isString($payment_transaction_id))
		error_1 ('The transaction ID is invalid.', $log_fp);
	elseif (!Validate::isLoadedObject($currency))
		error_1 ( 'The selected currency is invalid.', $log_fp);
	elseif ($order_has_invoice && !Validate::isLoadedObject($order_invoice))
		error_1 ('The invoice is invalid.', $log_fp);
//	elseif (!Validate::isDate($payment_date))
//		error_1 ('The date is invalid');
	else
	{

//print_r($obj_date);
//echo "<br>";
//print_r($order);	
//exit;	
//echo "<br>";

//exit;


	
		
	}

	
	
//добавляем оплату в базу	
//if (!$order->addOrderPayment($amount, $payment_method, $payment_transaction_id, $currency, $date, $order_invoice))
//			error_1('An error occurred during payment.');
	
// проверка на ошибку
// надо сделать проверку на сумму платежа и если не полностью оплатили нужно устанавливать статус не достаточно средств для оплаты
// в статусе необходимо казывать сумму сколько оплатитли
// оплачено... и переплата
// определяем сколько всего заплачено по инвойсу
//$invoice_paid = $order_invoice->getTotalPaid();	

//print_r ($order_invoice);
//echo '<br><br>' . $invoice_Paid;

//echo $order_invoice->total_paid_tax_incl;


//меняес статус на
		// устанавливаем сразy "оплачано" у этого статуса не должна быть активизированна опция "оплачен", "отправлен", "Принят"
			$id_order_state = 2;	

// если переплата то добавляем сумму в баланс
//$a1=  $invoice_Paid -$order_invoice->total_paid_tax_incl;
//if ($a1>0){
// заносим данные в базу
//$sql = 'INSERT INTO ps_balans_customers ( id_customer, id_currency, credit, transaction, description)  
//VALUE ('. $row['id_customer'] .',1,'. $row['summ_m'] .', \''. $transaction .'\', \''. $description . $row['post_address'] .'\') ;';


//}
					
						// Create new OrderHistory
						$history = new OrderHistory();
						$history->id_order =$order->id;
						// сотрудник admin
						$history->id_employee = 1;
//print_r($history);
						$use_existings_payment = false;
						if (!$order->hasInvoice())
							$use_existings_payment = true;
						// меняем историю 
						$history->changeIdOrderState($id_order_state, $order, $use_existings_payment);
// carrier
						$carrier = new Carrier($order->id_carrier, $order->id_lang);
						$templateVars = array();
						if ($history->id_order_state == Configuration::get('PS_OS_SHIPPING') && $order->shipping_number)
							$templateVars = array('{followup}' => str_replace('@', $order->shipping_number, $carrier->url));
						// Save all changes
						if ($history->addWithemail(true, $templateVars))
						{
							// synchronizes quantities if needed.. усли учитываем количество товара то уменьшаем количесто
						//	if (Configuration::get('PS_ADVANCED_STOCK_MANAGEMENT'))
						//	{
								foreach ($order->getProducts() as $product)
								{
								StockAvailable::updateQuantity($product['product_id'], $product['product_attribute_id'], -(int)$product['product_quantity']);
						//			if (StockAvailable::dependsOnStock($product['product_id']))
						//				StockAvailable::synchronize($product['product_id'], (int)$product['id_shop']);
								}
						//	}
	header("HTTP/1.0  200 ok!");
	echo "ok!";
	Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("COMMIT");
	fwrite($log_fp, "OK!!! \n"); // Запись в файл
	exit();	
						}
						error_1('An error occurred while changing order status, or we were unable to send an email to the customer.' , $log_fp);
	
	exit;
	}
	
}
function error_1($str, $log_fp )
{
	Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("ROLLBACK;");
	header("HTTP/1.0 404 Not Found");
	fwrite($log_fp, "Error:". $str. " \n"); // Запись в файл
 	echo $str;
	exit;
}	

?>