<?php 
class ModelPaymentCryptoPay extends Model {

	// вся инфо по модулю
	public function get_info() {
		$this->language->load('payment/cryptopay');
		return array(
				'code'       => 'cryptopay',
				'title'      => $this->language->get('text_title'),
				'description'=> $this->language->get('text_description'),
				'icon'		 => 'catalog/view/image/payment/cryptopay.png',
				'action'	 => 'pay', // ссылка на фнкцию для создания счета
				'sort_order' => $this->config->get('crypto_pay_sort_order'),
				'to_deposit'	 => true, // call by index.php?route=payment/MODULE_NAME/pay_dep
			);
	}

	public function getMethod($address, $total) {

		if ($total == 0) return;
		return $this->get_info();
	}

	// запомним платеж на депозит покупателя
	public function update_deposit($customer_id, $bal, $payed, $bill_secret) {		

		// изменим баланс пополнения для этого покупателя по нашей службе платежей
		$sql = 'UPDATE `' . DB_PREFIX . 'cryptopay_deposit` SET '
			. 'bal = ' . $bal
			. ', date_modified = NOW() WHERE customer_id = ' . $customer_id;
		$this->db->query($sql);

		$this->language->load('payment/multi_pay_tools');

		$description = $this->language->get('Income from') . ' <a href=\'http://cryptoPay.in/shop/bill/show/'
					. $bill_secret .'\' target=\'_blank\' class=\'button\'>cpyptoPay.in</a>';
		$this->load->model('payment/multi_pay_tools');
		$this->model_payment_multi_pay_tools->update_deposit($customer_id, $payed, $description);

	}
	
}
?>