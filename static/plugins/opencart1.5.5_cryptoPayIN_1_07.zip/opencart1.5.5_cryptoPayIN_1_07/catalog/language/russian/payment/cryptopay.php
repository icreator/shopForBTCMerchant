<?php
// Text
//$_['text_title'] = '<img src="http://cryptopay.in/shop/static/images/logo1.png" width="120" class="center"> - криптовалютами: bitcoin, litecoin, NVC, CLR...';
$_['text_title'] = '<b><font color="red">C</font>rypto<font color="red">P</font>ay.in</b>';
$_['text_description'] = 'Автоматический учет платежей в биткоинах и других критовалютах.';
$_['text_payment_link'] = 'Создан <b><a href="%s"  target="_blank" class="button">cчет</a></b> на оплату. '.
	'Вы можете <b><a href="%s" class="button">проверить оплату</a></b> вручную';
$_['text_payment_info_link'] = 'Счет оплачен. Статус: [%s]';
$_['text_payment_info_link_NOT'] = 'Счет НЕ оплачен. Статус: [%s]';
?>