<?php
define("ABR_DESCR", '<b>cryptoPay.in</b>: ');

class ControllerPaymentCryptoPay extends Controller {

	protected function index() {

		$this->load->helper('multi_pay');
        //текст кнопки подтверждения заказа
		$this->data['button_confirm'] = $this->language->get('button_confirm');
        //возьмем ссылку на страницу создания счета (а далее - редирект на страницу оплаты на cryptoPay)
		$this->data['action'] = $this->url->link('payment/cryptopay/pay');

		// добавили этот шаблон в общую папку
		$this->template = _tpl('/template/common/payment_confirm.tpl', $this->config->get('config_template'));

		$this->render();
	}
	
	private function make_bill($info) {
		$this->load->helper('multi_pay');
		// параметры на входе: цена, номер заказа, валюта
		// если нужно пополнить депозит то номер заказа име приставку 'DEP'
		// { price = 0, order_id = DEP123, curr = 'RUB' }

		$m_id = $this->config->get('cryptopay_merchant'); //
		if (strlen($m_id)>30) {
			// если вместо ИД_магазина адрес кошелька - значит конвертацию не передаем
			$conv = '';
		} else {
			$conv = $this->config->get('cryptopay_payout');
			if ($conv == 'AS_IS') {
				$conv = '';
			} else {
				if ($conv == 'not_convert') {
					// запрет конвертации
					$conv = '&not_convert';
				} else {
					// иначе тут задана валюта длля конвертации
					$conv = '&conv_curr=' . $conv;
				}
			}
		}
		
		// возьмем цену заказа
		$price = _g($info,'price', 0);
		$expr = ''; $back_url = '';
		if ($price>0) {
			// если цена есть то время жизни обработаем
			// время жизни счета проверим
			$expr = intval($this->config->get('cryptopay_expire'));
			if ($expr>10) {
				$expr = '&expire='.$expr;
			} else {
				$expr = '';
			}
		} else {
			// ссылка для возврата в магазин не на заказ а на историю пополнений депозита
			// закодируем спец символы
			$back_url = http_build_query(array( 'back_url' => '&route=account/transaction&w=',
				// значение платежа по умолчанию при пополнении депозита
				'vol' => $this->config->get('cryptopay_default_deposit'))
				);
			
		}
		//создаем ссылку с параметрами
		$m_url = 'http://cryptopay.in/shop/api_bill/make/'.$this->config->get('cryptopay_merchant').
			'?order='.$info['order_id'].
			$conv . $expr.
			($this->config->get('cryptopay_public')=='public'?'&public':'').
			(trim($this->config->get('cryptopay_extended'))!=''?$this->config->get('cryptopay_extended'):'').
			'&curr='.$info['curr'].
			'&price='.$price.
			(is_array($this->config->get('cryptopay_type'))?join('',array_map(function($type){return '&curr_in='.$type;}, $this->config->get('cryptopay_type'))):'').
			'&' . $back_url;
		//trigger_error ( ' URL api make: ' . $m_url, E_USER_NOTICE );
			
		$curl=curl_init( $m_url );
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl,CURLOPT_TIMEOUT,35);
		curl_setopt($curl,CURLOPT_HEADER,0);
		return curl_exec($curl);
	}
	
    public function pay() {
		$this->load->helper('multi_pay');

		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link(_url($_GET), 'SSL');
			$this->redirect($this->url->link('account/login', '', 'SSL'));
		}
        //сохраняем id заказа
        $order_id = _g($_GET,'order_id', _g($this->session->data,'order_id'));
		if (!$order_id) $this->redirect($this->url->link('account/order'));

        // проверим, может быть мы уже создавали счет для оплаты этого заказа?
        $query=$this->db->query('select bill_id from '.DB_PREFIX.'cryptopay_bill where order_id='.$order_id);
		//trigger_error ( '$query->row' . json_encode($query->row), E_USER_NOTICE );
        if($query->row) {
			// да - счет создан, просто его вернем
            $result=$query->row['bill_id'];
			// trigger_error ( ' cryptoPay bill_id exist - $result' . json_encode($result), E_USER_NOTICE );
        } else {

			//загружаем модель корзины-заказа
			$this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($order_id);
			
			// подтверждаем заказ (если он уже есть то там будет это проигнорировано)
			$this->load->model('payment/multi_pay_tools');
			$this->model_payment_multi_pay_tools->order_confirm($order_id, '', $order_info);
		
			$order_status_id = (int)$order_info['order_status_id'];
			//trigger_error ( '$order_info' . json_encode($order_info), E_USER_NOTICE );
			if ( $order_status_id != 0 && $order_status_id != 1) {
				// если заказ не новый и не в ожидании то пропустим
				//trigger_error ( ' заказ не новый - пропустим' . $order_status_id, E_USER_NOTICE );
				// заказ не встадии ожидания оплаты
				$this->language->load('account/multi_pay_order');
				$this->session->data['note'] = _note($this->language->get('note_cant_pay'),'warning');
				$this->redirect($this->url->link('account/order/info', '&order_id='.$order_id, 'SSL'));
			}
			// пришло сюда - значит создаем счет на оплату
			// через АПИ
			// тут и так все в глобальной валюте магазина $curr = $order_info['currency_code'];
			$curr = $this->config->get('config_currency');
			// не будем конвертировать? нет надо конвертировать а то курсы кривые внутри магазина
			// хотя если цена у товара задана в валюте конкретно... то наоборот не нужно конвертировать
			$price = $order_info['total']; // цена в глобальной валюте магазина в заказе хранится!
			$info = array(
					'order_id' => $order_id,
					'price' => $price,
					'curr' => $curr
					);
            $result = $this->make_bill($info);
			//trigger_error ( ' make_bill result: ' . json_encode($result), E_USER_NOTICE );

            //сохраняем bill_id
            $this->db->query('insert ignore into '.DB_PREFIX.'cryptopay_bill set order_id='
				.$order_id.', bill_id="'.$result.'"');

			//подключаем файл перевода
			$this->language->load('payment/multi_pay_tools');
			// создаем в примечании ссылки на счет и ссылку для принудительного запроса статуса оплаты
			// ссылка на счет
			$bill_url = '<b><a href="http://cryptopay.in/shop/bill/show/'.$result
				. '"  target="_blank" class="button">' . $this->language->get('bill') . '</a></b>';
			// ссылка на прринудительный запрос информации о счете
			$bill_reask_url = '<b><a href="index.php?route=payment/cryptopay/re_ask&bill='.$result.'&order='.$order_id
				. '" class="button">' . $this->language->get('bill_re_ask') . '</a></b>';
			$description = ABR_DESCR .sprintf(
					$this->language->get('bill_descr'), $bill_url, $bill_reask_url);

			// создаем в истории заказа запись что создан счет в платежной службе
			$this->model_payment_multi_pay_tools->order_bill_update(
					$order_id
					,$order_info
					,1 // Ожидание $this->config->get('config_order_status_id')
					,$description
					,true);
        }
        //редирект на страницу оплаты
        $this->redirect('http://cryptopay.in/shop/bill/show/'.$result);
    }

    // функция на которую приходит уведомление от сервиса
	public function callback(){
        
        //получаем из запроса bill_id
		// @ - подавляет вызов ошибки
        @$bill_id=$this->request->get['bill'];
        @$order_id=$this->request->get['order'];
		
        // ================================================================
        // по заказу проверять нельзя - так как тут может быть создано несколько счетов на один заказ
        // надо сделать LIKE по счету и все
        //
		// это депозит или заказ?
		$deposit = false;	
		
		if (substr($order_id,0,3) == 'DEP') {
			$customer_id = substr($order_id, 3);
			$deposit = true;
			$sql = 'select * from '.DB_PREFIX
				.'cryptopay_deposit where customer_id=' . $customer_id;
			//trigger_error ( ' sql: ' . $sql, E_USER_NOTICE );
			$query=$this->db->query($sql);
		} else {
			$query=$this->db->query('select bill_id, order_id from '.DB_PREFIX
				.'cryptopay_bill where order_id="'.$order_id.'"');
		}
		//trigger_error ( ' row: ' . json_encode($query->row), E_USER_NOTICE );
		//return 12;

        if($query->row)
        {
			// это наш счет прислал уведомление о смене статуса
			$bill_secret = $query->row['bill_id'];
			if ($deposit) {
				// это оплата депозита - задаим статус для поступивших платежей
				$bill_pars = $bill_secret . '?status=' . $this->config->get('cryptopay_bill_status');
			} else  $bill_pars = $bill_secret;
			//trigger_error ( ' bill_secret: ' . $bill_secret, E_USER_NOTICE );
			
            //проверяем оплату счета по api
			$curl=curl_init('http://cryptopay.in/shop/api_bill/check.json/'.$bill_pars);
			curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
			curl_setopt($curl,CURLOPT_TIMEOUT,5);
			curl_setopt($curl,CURLOPT_HEADER,0);
			$result = curl_exec($curl);
			//trigger_error ( ' result: ' . $result, E_USER_NOTICE );
			
			$result=json_decode($result);
			if ($deposit) {
				$this->accept_deposit( $customer_id, $query->row, $result, $bill_secret );
				return;
			}
			
			// ========================================
			// тут результатом может быть ошибка тоже - проверим
			if (isset($result->status))
			{
				$st = $result->status;
				$st_wait = $this->config->get('cryptopay_bill_status');
					
				// проверим - может такой статус оплаты уже сообщался нам
				$query_hist=$this->db->query('select order_id from '.DB_PREFIX
					.'order_history where order_id="'.$order_id.
						'" and comment like "%' . $st . '%"');
				if($query_hist->row) {
					// такой статус уже есть в истории заказа - игнорируем
					// trigger_error ( ' status exist: ' . $st, E_USER_NOTICE );					
					return;
				}
				
				//загружаем файл перевода
				//$this->language->load('payment/cryptopay');
				$this->language->load('payment/multi_pay_tools');
				
				//загружаем модель заказа
				$this->load->model('checkout/order');
				$order_info = $this->model_checkout_order->getOrder($order_id);
				//trigger_error ( 'checkout/order order_status_id: ' . $order_info['order_status_id'], E_USER_NOTICE );

				$order_status_id = (int)$order_info['order_status_id'];
				//trigger_error ( ' order_status_id: ' . $order_status_id . ' bill_status:' . $st, E_USER_NOTICE );					

				if ($st=='CLOSED'
						|| $st=='HARD' && ($st_wait=='HADR' || $st_wait=='SOFT')
						|| $st=='SOFT' && $st_wait=='SOFT'
						) {
					// если статусы счета подходят, то он полностью оплачен
					// поменяем и статус заказа
					$new_status_id = 2; // Обработка
					
					$this->load->model('payment/multi_pay_tools');
					$note_status = ABR_DESCR . sprintf($this->language->get('bill_payed'), $st);
					$this->model_payment_multi_pay_tools->order_bill_update(
							$order_id
							,$order_info
							,$new_status_id
							,$note_status
							,true
							);
				} elseif ($st=='NEW' || $st=='FILL') {
					// без изменений
				} else {
					//ставим статус заказа "НЕ оплачен"
					$note_status = sprintf($this->language->get('bill_payed_NOT'), $st);
					//trigger_error ( ' note_status: ' . $note_status, E_USER_NOTICE );
					$this->model_checkout_order->update(
						$order_id,
						$order_status_id, // - Canceled $this->config->get('cryptopay_order_status_id'),
						$note_status,
						true); // true - вывод в списке статусов в истории заказов
				}
			}
        } else {
			// отладка что ничего не добавляем - запись не нашлась
			// $this->db->query("INSERT INTO log SET msg = 'row not found " . $bill_id ."'");
		}
	}

	// функция для ручной проверки оплаты
	public function re_ask(){
		$this->callback();
		//редирект на страницу оплаты
		$this->redirect('index.php?route=account/order/info&order_id='.$this->request->get['order']);
	}

	// учтем приход денег на депозит
	private function  accept_deposit( $customer_id, $row, $info, $bill_secret ) {
		//trigger_error ( ' customer_id: ' . $customer_id, E_USER_NOTICE );
		//trigger_error ( ' row: ' . json_encode($row), E_USER_NOTICE );
		//trigger_error ( ' info: ' . json_encode($info), E_USER_NOTICE );
		
		//{"payed": 8.80995405, "status": "FILL", "price": 0.0, "curr": "RUB", "order": "DEP1"}
		
		// тут надо посмотреть сколько уже было оплачено до этого
		if ($row['bal']) {
			if ($row['bal'] < $info->payed) {
				$new_payed = $info->payed - $row['bal'];
			} else {
				$new_payed = 0;
			}
		} else {
			$new_payed = $info->payed;
		}

		//trigger_error ( ' new_payed: ' . $new_payed, E_USER_NOTICE );
		// если произошла доплата то запомним
		if ($new_payed > 0) {
			$this->load->model('payment/cryptopay');
			$this->model_payment_cryptopay->update_deposit($customer_id, $info->payed, $new_payed, $bill_secret);
		}

	}
	
	// функция для пополнения депозита
	public function pay_dep() {
	
		$customer_id = $this->customer->isLogged();
		if (!$customer_id) {
			$this->session->data['redirect'] = $this->url->link('', '', 'SSL');
			$this->redirect($this->url->link('account/login', '', 'SSL'));
		}

		// создадим счет
        $query=$this->db->query('select bill_id from '.DB_PREFIX
			.'cryptopay_deposit where customer_id='
			.$customer_id);
			
		//trigger_error ( ' - : ' . json_encode($query->row), E_USER_NOTICE );
	
        if($query->row)  {
            $result=$query->row['bill_id'];
        }
        else {
            //создаем счет через АПИ
			$info = array( 'order_id' => 'DEP' . $customer_id,
				'curr' => $this->config->get('config_currency'), // валюта платежа
				'vol' => $this->config->get('cryptopay_default_deposit'), // сколько в поле цены выставить по умолчанию
				);
  			//$info = array( 'order_id' => order_info['order_id'], 'price' => $price, 'curr' => $curr);
			$result=$this->make_bill($info);

			//trigger_error ( ' new bill_id: ' . $result, E_USER_NOTICE );
            //сохраняем bill_id
            $this->db->query('insert ignore into '.DB_PREFIX.'cryptopay_deposit set customer_id='
				.$customer_id.', bill_id="'.$result.'"');
		}
		
        //редирект на страницу оплаты
        $this->redirect('http://cryptopay.in/shop/bill/show/'.$result);
			
	}
}
?>