<?php
class ControllerPaymentCryptoPay extends Controller {
	protected function index() {
        $this->language->load('payment/cryptopay');

        //текст кнопки подтверждения заказа
		$this->data['button_confirm'] = $this->language->get('button_confirm');
        //ссылка на страницу создания счета (далее - редирект на страницу оплаты на cryptoPay)
		$this->data['action'] = $this->url->link('payment/cryptopay/pay');

        //вывод шаблона
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/cryptopay.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/payment/cryptopay.tpl';
		} else {
			$this->template = 'default/template/payment/cryptopay.tpl';
		}
		$this->render();
	}
    public function pay()
    {
        //подключаем файл перевода
        $this->language->load('payment/cryptopay');
        //загружаем модель заказа
        $this->load->model('checkout/order');
        //сохраняем id заказа
        $order_id=$this->session->data['order_id'];

        //очищаем корзину
        if (isset($this->session->data['order_id'])) {
            $this->cart->clear();
            unset($this->session->data['shipping_method']);
            unset($this->session->data['shipping_methods']);
            unset($this->session->data['payment_method']);
            unset($this->session->data['payment_methods']);
            unset($this->session->data['guest']);
            unset($this->session->data['comment']);
            unset($this->session->data['order_id']);
            unset($this->session->data['coupon']);
            unset($this->session->data['reward']);
            unset($this->session->data['voucher']);
            unset($this->session->data['vouchers']);
        }
        //получаем инфо заказа
        $query=$this->db->query('select bill_id from '.DB_PREFIX.'cryptopay_bill where order_id='.$order_id);
        if($query->row)
        {
            $result=$query->row['bill_id'];
        }
        else
        {
            $order_info = $this->model_checkout_order->getOrder($order_id);
			
            //создаем счет через АПИ
            $curl=curl_init('http://cryptopay.in/shop/api_bill/make/'.$this->config->get('cryptopay_merchant').'?order='.$order_id.
                ($this->config->get('cryptopay_payout')!='not_convert'?"&conv_curr=".$this->config->get('cryptopay_payout'):'').
                ($this->config->get('cryptopay_public')=='public'?"&public":'').
                ($this->config->get('cryptopay_expire')!=''?"&expire=".$this->config->get('cryptopay_expire'):'').
                (trim($this->config->get('cryptopay_extended'))!=''?$this->config->get('cryptopay_extended'):'').

                '&curr='.$order_info['currency_code'].'&price='.$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false).
                (is_array($this->config->get('cryptopay_type'))?join('',array_map(function($type){return '&curr_in='.$type;}, $this->config->get('cryptopay_type'))):''));
            curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
            curl_setopt($curl,CURLOPT_TIMEOUT,5);
            curl_setopt($curl,CURLOPT_HEADER,0);
            $result=curl_exec($curl);

            //сохраняем bill_id
            $this->db->query('insert ignore into '.DB_PREFIX.'cryptopay_bill set order_id='.$order_id.', bill_id="'.$result.'"');

            //"подтверждаем заказ"
            $this->model_checkout_order->confirm($order_id,$this->config->get('config_order_status_id'),sprintf($this->language->get('text_payment_link'), 'http://cryptopay.in/shop/bill/show/'.$result),true);
        }
        //редирект на страницу оплаты
        $this->redirect('http://cryptopay.in/shop/bill/show/'.$result);
    }
	public function callback() {
	
        //загружаем файл перевода
        $this->language->load('payment/cryptopay');
        //получаем из запроса order_id + bill_id
        $order_id=isset($this->request->get['order_id'])?$this->request->get['order_id']:$this->request->get['order'];
        @$bill_id=isset($this->request->get['bill_id'])?$this->request->get['bill_id']:$this->request->get['bill'];

        // проверяем наличие в базе
        $query=$this->db->query('select bill_id from '.DB_PREFIX.'cryptopay_bill where order_id='.$order_id.' and bill_id like "'.$bill_id.'%"');

        if($query->row)
        {
                $bill_secret=$query->row['bill_id'];
            //проверяем оплату счета по api
                $curl=curl_init('http://cryptopay.in/shop/api_bill/check.json/'.$bill_secret);
                curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($curl,CURLOPT_TIMEOUT,5);
                curl_setopt($curl,CURLOPT_HEADER,0);
                $result=json_decode(curl_exec($curl));
            //если совпали order_id, статусы заказа и счет полностью оплачен
                if($result->order==$order_id  && $result->price==$result->payed && ($result->status==$this->config->get('cryptopay_bill_status') || $result->status=='CLOSED'))
                {
                    //загружаем модель заказа
                    $this->load->model('checkout/order');
                    //ставим статус заказа "оплачен" (из настроек модуля оплаты)
                    $this->model_checkout_order->update($order_id,$this->config->get('cryptopay_order_status_id'),sprintf($this->language->get('text_payment_info_link'), 'http://cryptopay.in/shop/bill/show/'.$bill_secret),true);
                }

        }
	}
}
?>