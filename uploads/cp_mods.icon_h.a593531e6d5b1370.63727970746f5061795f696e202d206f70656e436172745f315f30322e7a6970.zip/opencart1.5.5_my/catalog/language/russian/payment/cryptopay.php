<?php
// Text
$_['text_title'] = '<img src="http://cryptopay.in/shop/static/images/logo1.png" width="120" class="center"> - криптовалютами: bitcoin, litecoin, NVC, CLR...';
$_['text_payment_link'] = '<a href="%s">Счет сформирован</a>';
$_['text_payment_info_link'] = '<a href="%s">Счет оплачен. Статус: [%s]</a>';
?>